package com.paxata.services.transform;

/**
 * Created by Grant Liu on 6/25/16.
 */
public class FixUserName {

    public static String prependA(String value) {
        return (value == null ? null : "a"+value);
    }
}
